package HomeWorkQA21m_2_v2;

public class App {
    public static void main(String[] args) {

        ProductItem p1 = new ProductItem("P001", "Картофель", 2.5, "кг.");
        ProductItem p2 = new ProductItem("P002", "Морковь  ", 2.8, "кг.");
        ProductItem p3 = new ProductItem("P003", "Помидоры ", 3.7, "кг.");
        ProductItem p4 = new ProductItem("P004", "Огурцы   ", 1.5, "кг.");
        ProductItem p5 = new ProductItem("P004", "Яблоки   ", 3.2, "кг.");
        ProductItem p6 = new ProductItem("P004", "Апельсины", 2.1, "кг.");
        ProductItem p7 = new ProductItem("P005", "Манго    ", 5.5, "кг.");

        Shop real = new Shop("Real");
        real.addProduct(p1);
        real.addProduct(p2);
        real.addProduct(p3);
        real.addProduct(p4);
        real.addProduct(p5);
        real.addProduct(p6);

        real.addProductInAction(p2,25);
        real.addProductInAction(p5,25);

        real.addProductInAction(p3,10);
//        real.addProductInAction(p3,15); // повторно добавляем продукт в акцию

        Cart cart1 = new Cart(real);
        cart1.addProductCart(p1, 10);
        cart1.addProductCart(p2, 2);
        cart1.addProductCart(p3, 3);
        cart1.addProductCart(p4, 1);
        cart1.addProductCart(p5, 3);
        cart1.addProductCart(p6, 5);
//        cart1.addProductCart(p7, 1); // кладем в корзину продукт, которого нет в магазине

        cart1.printCheck();
    }
}
