package HomeWorkQA21m_2_v2;

import java.util.ArrayList;

public class Shop {
    private ArrayList<ProductItem> products = new ArrayList<>(); // продукты в магазине
    private ArrayList<Action> actions = new ArrayList<>(); // акции
    private String name; // название магазина

    public Shop(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void addProduct(ProductItem p) {
        products.add(p);
    }

    public int indexOfProduct(ProductItem p) {
        return products.indexOf(p);
    }

    public void addProductInAction(ProductItem p, int discount) { // добавляем продукт в акцию
        if (findDiscountValue(p) == 0) { // продукта нет ни в одной акции
            if (findAction(discount) == null) { // если акции с такой скидкой еще нет, создаем ее и добавляем продукт
                Action a = new Action();
                a.setDiscount(discount);
                a.addActionProduct(p);
                actions.add(a);
            } else { // добавляем продукт к существующей акции
                findAction(discount).addActionProduct(p);
            }
        } else
            System.out.println("Shop: На продукт " + p + " уже действует скидка " + findDiscountValue(p) + "%!");
    }

    private Action findAction(int discount) { // возвращает акцию по значению скидки
        for (int i = 0; i < actions.size(); i++) {
            if (actions.get(i).getDiscount() == discount)
                return actions.get(i);
        }
        return null;
    }

    public int findDiscountValue(ProductItem p) { // возвращает значение скидки на продукт
        for (Action a : actions
        ) {
            if (a.isActionProduct(p)) {
                return a.getDiscount();
            }
        }
        return 0;
    }
}
