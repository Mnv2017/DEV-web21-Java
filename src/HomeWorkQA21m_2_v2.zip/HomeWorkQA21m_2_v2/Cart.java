package HomeWorkQA21m_2_v2;

import java.util.ArrayList;
import java.util.Locale;

public class Cart {
    private Shop shop; // в каком магазине совершаем покупку
    private ArrayList<ProductInCart> productsC = new ArrayList<>(); // продукты в корзине

    public Cart(Shop shop) {
        this.shop = shop;
    }

    public void addProductCart(ProductItem p, int amount) {
        if (shop.indexOfProduct(p) >= 0) { // продукт есть в магазине
            ProductInCart pCart = new ProductInCart(p, amount); // создаем продукт с обычной ценой
            if (shop.findDiscountValue(p) != 0) { // продукт среди акционных - меняем его цену
                pCart.setProductPrice(pCart.getProduct().getPrice() * (100 - shop.findDiscountValue(p)) / 100.0);
            }
            productsC.add(pCart); // добавляем в корзину
        } else {
            System.out.println("Cart: Продукт " + p.getName() + " отсутствует в ассортименте магазина!");
        }
    }

    public void printCheck() {
        System.out.println("\n*******    Покупка в магазине: " + shop.getName() + "  *******");
        double sum = 0; // сумма ИТОГО
        for (ProductInCart pC : productsC) {
            double sumI = pC.getAmount() * pC.getProduct().getPrice(); // сумма по строке
            sum += sumI;
            String discString = "";
            int discInt = shop.findDiscountValue(pC.getProduct());
            if (discInt != 0) { // если есть скидка, будем ее выводить
                discString = "  -" + discInt + "%";
            }
            System.out.println(pC + "........" + String.format(Locale.US, "%5.2f", sumI) + " EUR " + discString);
        }
        System.out.printf(Locale.US, "ИТОГО:.........................%.2f", sum);
        System.out.println(" EUR");
    }

}
