package HomeWorkQA21m_2_v2;

import java.util.HashSet;

public class Action {
    private HashSet<ProductItem> actions = new HashSet<>(); // продукты по акции
    private int discount; // размер cкидки в %

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public void addActionProduct(ProductItem p) {
        if (!actions.add(p)) {
            System.out.println("Shop: Этот продукт уже есть в списке акционных товаров со скидкой " + discount);
        }
    }

    public boolean isActionProduct(ProductItem p) {
        return actions.contains(p);
    }

    @Override
    public String toString() {
        return "Action{" +
                "actions=" + actions +
                ", discount=" + discount +
                '}';
    }
}
