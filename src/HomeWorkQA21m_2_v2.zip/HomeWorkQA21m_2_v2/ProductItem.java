package HomeWorkQA21m_2_v2;

public class ProductItem {
    private String code; // штрих-код
    private String name; // название
    private double price; // цена за единицу
    private String unit; // единица измерения

    public ProductItem(String code, String name, double price, String unit) {
        this.code = code;
        this.name = name;
        this.price = price;
        this.unit = unit;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getUnit() {
        return unit;
    }

    @Override
    public String toString() {
        return "ProductItem{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", unit='" + unit + '\'' +
                '}';
    }
}
