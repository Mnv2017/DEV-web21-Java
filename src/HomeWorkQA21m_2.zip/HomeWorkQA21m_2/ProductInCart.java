package HomeWorkQA21m_2;

import java.util.Locale;

public class ProductInCart {
    private ProductItem product;
    private int amount;

    public ProductInCart(ProductItem product, int amount) {
        this.product = product;
        this.amount = amount;
    }

    public void setProductPrice(double price) {
        product.setPrice(price);
    }

    public ProductItem getProduct() {
        return product;
    }

    public int getAmount() {
        return amount;
    }

    public String toString() {
        return product.getName() + " " +
                amount + " " +
                product.getUnit() + " x " +
                String.format(Locale.US,"%.2f", product.getPrice());
    }
}
