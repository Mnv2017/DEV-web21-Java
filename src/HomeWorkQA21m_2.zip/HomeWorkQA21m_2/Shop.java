package HomeWorkQA21m_2;

import java.util.ArrayList;
import java.util.HashSet;

public class Shop {
    private ArrayList<ProductItem> products = new ArrayList<>(); // продукты в магазине
    private HashSet<ProductItem> actions = new HashSet<>(); // продукты по акции
    private String name; // название магазина
    private int discount; // размер cкидки в %

    public Shop(String name, int discount) {
        this.name = name;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }


    public int getDiscount() {
        return discount;
    }

    public double getDoubleDiscount() {
        return discount/100.0;
    }

    public void addProduct(ProductItem p){
        products.add(p);
    }

    public int indexOfProduct(ProductItem p){
        return products.indexOf(p);
    }

    public void addAction(ProductItem p){
        if (!actions.add(p)){
            System.out.println("Shop: Этот продукт уже есть в списке акционных товаров!");
        };
    }

    public boolean isActionProduct(ProductItem p){
        return actions.contains(p);
    }
}
